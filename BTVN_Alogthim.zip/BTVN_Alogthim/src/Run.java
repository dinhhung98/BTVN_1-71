import java.util.Scanner;

/**
 * @author HungND72
 */
public class Run {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        Main solution = new Main();
        System.out.println("Bai 1: " + solution.exam1(n));
        System.out.println("Bai 2: " + solution.exam2(n));
        System.out.println("Bai 3: " + solution.exam3(n));
        System.out.println("Bai 4: " + solution.exam4(n));
        System.out.println("Bai 5: " + solution.exam5(n));
        System.out.println("Bai 6: " + solution.exam6(n));
        System.out.println("Bai 7: " + solution.exam7(n));
        System.out.println("Bai 8: " + solution.exam8(n));
        System.out.println("Bai 9: " + solution.exam9(n));
        System.out.println("Bai 10: " + solution.exam10(n, 2));
        System.out.println("Bai 11: " + solution.exam11(n));
        System.out.println("Bai 12: " + solution.exam12(n, 2));
        System.out.println("Bai 13: " + solution.exam13(n, 2));
        System.out.println("Bai 14: " + solution.exam14(n, 2));
        System.out.println("Bai 15: " + solution.exam15(n));
        System.out.println("Bai 16: " + solution.exam16(n, 2));
        System.out.println("Bai 17: " + solution.exam17(n, 2));
        System.out.println("Bai 18: " + solution.exam18(n, 2));
        System.out.println("Bai 19: " + solution.exam19(n, 2));
        System.out.print("Bai 20: ");
        solution.exam20(n);
        System.out.println();
        System.out.println("Bai 21: " + solution.exam21(n));
        System.out.println("Bai 22: " + solution.exam22(n));
        System.out.println("Bai 23: " + solution.exam23(n));
        System.out.print("Bai 24: ");
        solution.exam24(n);
        System.out.println();
        System.out.println("Bai 25: " + solution.exam25(n));
        System.out.println("Bai 26: " + solution.exam26(n));
        System.out.println("Bai 27: " + solution.exam27(n));
        System.out.println("Bai 28: " + solution.exam28(n));
        System.out.println("Bai 29: " + solution.exam29(n));
        System.out.println("Bai 30: " + solution.exam30(n));
        System.out.println("Bai 31: " + solution.exam31(n));
        System.out.println("Bai 32: " + solution.exam32(n));
        System.out.println("Bai 33: " + solution.exam33(n));
        System.out.println("Bai 34: " + solution.exam34(n));
        System.out.println("Bai 35: " + solution.exam35(n));
        System.out.println("Bai 36: " + solution.exam36(n));
        System.out.println("Bai 37: " + solution.exam37(n));
        System.out.println("Bai 38: " + solution.exam38(n));
        System.out.println("Bai 39: " + solution.exam39(n));
        System.out.println("Bai 40: " + solution.exam40(n, 2));
        System.out.println("Bai 41: " + solution.exam41(n));
        System.out.println("Bai 42: " + solution.exam42(n));
        System.out.println("Bai 43: " + solution.exam43(n));
        System.out.println("Bai 44: " + solution.exam44(n));
        System.out.println("Bai 45: " + solution.exam45(n));
        System.out.println("Bai 46: " + solution.exam46(n));
        System.out.println("Bai 47: " + solution.exam47(n));
        System.out.println("Bai 48: " + solution.exam48(n));
        System.out.println("Bai 49: " + solution.exam49(n));
        System.out.println("Bai 50: " + solution.exam50(n));
        System.out.println("Bai 51: " + solution.exam51(n));
        System.out.println("Bai 52: " + solution.exam52(n));
        System.out.println("Bai 53: " + solution.exam53(n));
        System.out.println("Bai 54: " + solution.exam54(n));
        System.out.println("Bai 55: " + solution.exam55(n));
        System.out.println("Bai 56: " + solution.exam56(n));
        System.out.println("Bai 57: " + solution.exam57(n));
        System.out.println("Bai 58: " + solution.exam58(n));
        System.out.println("Bai 59: " + solution.exam59(n));
        System.out.println("Bai 60: " + solution.exam60(n));
        System.out.println("Bai 61: " + solution.exam61(n));
        System.out.println("Bai 62: " + solution.exam62(n, 2));
        System.out.println("Bai 63: " + solution.exam63(n, 2));
        System.out.println("Bai 64: " + solution.exam64(n, 2));
        System.out.println("Bai 65: " + solution.exam65(n, 2, 2));
        System.out.println("Bai 66: " + solution.exam66(n, 2, 2));
        System.out.println("Bai 67: " + solution.exam67(n, 2));
        System.out.println("Bai 68: " + solution.exam68(n, 2));
        System.out.println("Bai 69: " + solution.exam69(n, 2));
        System.out.println("Bai 70: " + solution.exam70(n));
        System.out.println("Bai 71: " + solution.exam71(n, 2));
    }
}
