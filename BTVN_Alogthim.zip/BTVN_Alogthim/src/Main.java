/**
 * @author HungND72
 */
public class Main {
    public int exam1(int n) {
        return n * (1 + n) / 2;
    }

    public int exam2(int n) {
        return n * (n + 1) * (2 * n + 1) / 6;
    }

    public double exam3(int n) {
        double sum = 1;
        for (int i = 2; i <= n; i++) {
            sum += (float) 1 / i;
        }
        return sum;
    }

    public float exam4(int n) {
        return 1 - (float) 1 / (2 * n);
    }

    public double exam5(int n) {
        double sum = 1;
        for (int i = 1; i <= n; i++) {
            sum += (double) 1 / (2 * i + 1);
        }
        return sum;
    }

    public double exam6(int n) {
        return 1 - (double) 1 / (n + 1);
    }

    public double exam7(int n) {
        double sum = 0;
        for (int i = 1; i <= n; i++) {
            sum += (double) i / (i + 1);
        }
        return sum;
    }

    public double exam8(int n) {
        double sum = 0;
        for (int i = 1; i <= 2 * n; i++) {
            sum += (double) i / (i + 1);
            i++;
        }
        return sum;
    }

    public long exam9(int n) {
        long total = 1;
        for (int i = 2; i <= n; i++) {
            total *= i;
        }
        return total;
    }

    public long exam10(int x, int y) {
        long total = 1;
        for (int i = 1; i <= y; i++) {
            total *= x;
        }
        return total;
    }

    public long exam11(int n) {
        long total = 1;
        long gt = 1;
        for (int i = 1; i <= n; i++) {
            gt *= i;
            total += gt;
        }
        return total;
    }

    public long exam12(int n, int x) {
        long total = 1;
        long gt = 1;
        for (int i = 1; i <= n; i++) {
            gt *= x;
            total += gt;
        }
        return total;
    }

    public long exam13(int n, int x) {
        long total = 1;
        long gt = 1;
        for (int i = 1; i <= n; i++) {
            gt = gt * x * x;
            total += gt;
        }
        return total;
    }

    public long exam14(int n, int x) {
        long total = 1;
        long gt = x;
        for (int i = 1; i < n; i++) {
            gt = gt * x * x;
            total += gt;
        }
        return total;
    }

    public double exam15(int n) {
        double total = 1;
        int gt = 1;
        for (int i = 2; i <= n; i++) {
            gt += i;
            total += (double) 1 / gt;
        }
        return total;
    }

    public double exam16(int n, int x) {
        double total = 1;
        int ms = 1;
        long ts = x;
        total = (double) ts / ms;
        for (int i = 2; i <= n; i++) {
            ms += i;
            ts *= x;
            total += (double) ts / ms;
        }
        return total;
    }

    public double exam17(int n, int x) {
        double total = 1;
        int ms = 1;
        long ts = x;
        total = (double) ts / ms;
        for (int i = 2; i <= n; i++) {
            ms *= i;
            ts *= x;
            total += (double) ts / ms;
        }
        return total;
    }

    public double exam18(int n, int x) {
        double total = 1;
        int ms = 1;
        long ts = 1;
        total = (double) ts / ms;
        for (int i = 1; i <= 2 * n; i++) {
            ms = ms * i * (i + 1);
            ts = ts * x * x;
            total += (double) ts / ms;
            i++;
        }
        return total;
    }

    public double exam19(int n, int x) {
        double total = 1;
        int ms = 1;
        long ts = x;
        total = (double) ts / ms;
        for (int i = 2; i < 2 * n; i++) {
            ms = ms * i * (i + 1);
            ts = ts * x * x;
            total += (double) ts / ms;
            i++;
        }
        return total;
    }

    public void exam20(int n) {
        int m = (int) Math.sqrt(n);
        for (int i = 1; i <= m; i++) {
            if (n % i == 0) System.out.print(i + " " + (n / i) + " ");
        }
        System.out.println();
    }

    public int exam21(int n) {
        int m = (int) Math.sqrt(n);
        int sum = 0;
        for (int i = 1; i <= m; i++) {
            if (n % i == 0) sum = sum + i + (n / i);
        }
        return sum;
    }

    public long exam22(int n) {
        int m = (int) Math.sqrt(n);
        long sum = 1;
        for (int i = 1; i <= m; i++) {
            if (n % i == 0) sum = sum * i * (n / i);
        }
        return sum;
    }

    public int exam23(int n) {
        int m = (int) Math.sqrt(n);
        int sum = 0;
        for (int i = 1; i <= m; i++) {
            if (n % i == 0) sum += 2;
        }
        if (m * m == n) sum -= 1;
        return sum;
    }

    public void exam24(int n) {
        int m = (int) Math.sqrt(n);
        int sum = 0;
        for (int i = 1; i <= m; i++) {
            if (i % 2 != 0 && n % i == 0) {
                System.out.print(i);
                if ((n / i) % 2 != 0) System.out.print(" " + n / i);
            }
        }
        System.out.println();
    }

    public int exam25(int n) {
        int m = (int) Math.sqrt(n);
        int sum = 0;
        for (int i = 1; i <= m; i++) {
            if (i % 2 == 0 && n % i == 0) {
                sum += i;
                if ((n / i) % 2 == 0) sum += n / i;
            }
        }
        if (m % 2 == 0 && m * m == n) {
            sum -= m;
        }
        return sum;
    }

    public int exam26(int n) {
        int m = (int) Math.sqrt(n);
        int resulf = 0;
        for (int i = 1; i <= m; i++) {
            if (i % 2 != 0 && n % i == 0) {
                resulf *= i;
                if ((n / i) % 2 != 0) resulf *= n / i;
            }
        }
        if (m % 2 != 0 && m * m == n) {
            resulf /= m;
        }
        return resulf;
    }

    public int exam27(int n) {
        int m = (int) Math.sqrt(n);
        int resulf = 0;
        for (int i = 1; i <= m; i++) {
            if (i % 2 == 0 && n % i == 0) {
                resulf++;
                if ((n / i) % 2 != 0) resulf++;
            }
        }
        if (m % 2 == 0 && m * m == n) {
            resulf--;
        }
        return resulf;
    }

    public int exam28(int n) {
        int m = (int) Math.sqrt(n);
        int resulf = 1;
        for (int i = 2; i < m; i++) {
            if (n % i == 0) {
                resulf += i;
                resulf += n / i;
            }
        }
        if (m * m == n) {
            resulf += m;
        }
        return resulf;
    }

    public int exam29(int n) {
        int m = (int) Math.sqrt(n);
        int resulf = 1;
        for (int i = 1; i < m; i++) {
            if (n % i == 0 && (n / i) % 2 != 0) {
                resulf = n / i;
                break;
            }
        }
        return resulf;
    }

    public String exam30(int n) {
        return "Khong biet so hoan thien la so nhu nao";
    }

    public boolean exam31(int n) {
        int m = (int) Math.sqrt(n);
        if (n == 2) return true;
        if (n < 2) return false;
        for (int i = 2; i <= m; i++) {
            if (n % i == 0) return false;
        }
        return true;
    }

    public boolean exam32(int n) {
        int m = (int) Math.sqrt(n);
        if (m * m == n) return true;
        return false;
    }

    public float exam33(int n) {
        float total = 0;
        for (int i = 1; i <= n; i++) {
            total = (float) Math.sqrt(2 + total);
        }
        return total;
    }

    public float exam34(int n) {
        float total = 0;
        for (int i = 1; i <= n; i++) {
            total = (float) Math.sqrt(i + total);
        }
        return total;
    }

    public float exam35(int n) {
        float total = 0;
        for (int i = n; i >= 1; i--) {
            total = (float) Math.sqrt(i + total);
        }
        return total;
    }

    public float exam36(int n) {
        float total = 0;
        int temp = 1;
        for (int i = 1; i <= n; i++) {
            temp *= i;
            total = (float) Math.sqrt(temp + total);
        }
        return total;
    }

    public float exam37(int n) {
        float total = 0;
        int temp = 1;
        for (int i = 2; i <= n; i++) {
            total = (float) Math.pow((total + i), 1 / i);
        }
        return total;
    }

    public float exam38(int n) {
        float total = 0;
        int temp = 1;
        for (int i = 1; i <= n; i++) {
            total = (float) Math.pow((total + i), 1 / (i + 1));
        }
        return total;
    }

    public float exam39(int n) {
        float total = 0;
        int temp = 1;
        for (int i = 1; i <= n; i++) {
            temp *= i;
            total = (float) Math.pow((total + temp), 1 / (i + 1));
        }
        return total;
    }

    public float exam40(int n, int x) {
        float total = 0;
        int temp = 1;
        for (int i = 1; i <= n; i++) {
            temp *= x;
            total = (float) Math.sqrt(total + temp);
        }
        return total;
    }

    public float exam41(int n) {
        float total = 1;
        int temp = 1;
        for (int i = 1; i <= n; i++) {
            total = 1 + (float) Math.pow((total + 1), -1);
        }
        return total;
    }

    public int exam42(int n) {
        int temp = 0;
        temp = (int) ((Math.sqrt(8 * n + 1) - 1) / 2);
        if (temp == n) return temp--;
        return temp;
    }

    public int exam43(int n) {
        int count = 0;
        while (n > 0) {
            n /= 10;
            count++;
        }
        return count;
    }

    public int exam44(int n) {
        int count = 1;
        while (n > 0) {
            count += n % 10;
            n /= 10;
        }
        return count;
    }

    public int exam45(int n) {
        int count = 1;
        while (n > 0) {
            count *= n % 10;
            n /= 10;
        }
        return count;
    }

    public int exam46(int n) {
        int count = 0;
        while (n > 0) {
            if (n % 10 != 0) count++;
            n /= 10;
        }
        return count;
    }

    public int exam47(int n) {
        int count = 0;
        while (n > 0) {
            if (n % 10 == 0) count += n % 10;
            n /= 10;
        }
        return count;
    }

    public int exam48(int n) {
        int count = 0;
        while (n > 0) {
            if (n % 10 != 0) count *= n % 10;
            n /= 10;
        }
        return count;
    }

    public int exam49(int n) {
        while (n > 10) {
            n /= 10;
        }
        return n;
    }

    public int exam50(int n) {
        int temp = 0;
        while (n > 0) {
            temp = temp * 10 + n % 10;
            n /= 10;
        }
        return temp;
    }

    public int exam51(int n) {
        int temp = n % 10;
        while (n > 0) {
            if (temp < n % 10) temp = n % 10;
            n /= 10;
        }
        return temp;
    }

    public int exam52(int n) {
        int temp = n % 10;
        while (n > 0) {
            if (temp > n % 10) temp = n % 10;
            n /= 10;
        }
        return temp;
    }

    public int exam53(int n) {
        int temp = n % 10;
        int count = 0;
        int m = n;
        while (n > 0) {
            if (temp < n % 10) temp = n % 10;
            n /= 10;
        }
        while (m > 0) {
            if (temp == m % 10) count++;
            m /= 10;
        }
        return count;
    }

    public int exam54(int n) {
        int temp = n % 10;
        int count = 0;
        int m = n;
        while (n > 0) {
            if (temp > n % 10) temp = n % 10;
            n /= 10;
        }
        while (m > 0) {
            if (temp == m % 10) count++;
            m /= 10;
        }
        return count;
    }

    public int exam55(int n) {
        int temp = n % 10;
        int count = 0;
        while (n > 0) {
            if (temp == n % 10) count++;
            n /= 10;
        }
        count--;
        return count;
    }

    public boolean exam56(int n) {
        while (n > 0) {
            if (n % 10 == 0) return false;
            n /= 10;
        }
        return true;
    }

    public boolean exam57(int n) {
        while (n > 0) {
            if (n % 10 != 0) return false;
            n /= 10;
        }
        return true;
    }

    public String exam58(int n) {
        return "De giong bai 57";
    }

    public boolean exam59(int n) {
        int temp = 0;
        int m = n;
        while (n > 0) {
            temp = temp * 10 + n % 10;
            n /= 10;
        }
        if (temp == m) return true;
        return false;
    }

    public boolean exam60(int n) {
        int temp = n % 10;
        n /= 10;
        int m = n;
        while (n > 0) {
            if (temp < n % 10) return false;
            temp = n % 10;
            n /= 10;
        }
        if (temp == m) return true;
        return false;
    }

    public boolean exam61(int n) {
        int temp = n % 10;
        n /= 10;
        int m = n;
        while (n > 0) {
            if (temp > n % 10) return false;
            temp = n % 10;
            n /= 10;
        }
        if (temp == m) return true;
        return false;
    }

    public int exam62(int n, int x) {
        if (x == 0) return n;
        return exam62(x, n % x);
    }

    public int exam63(int n, int x) {
        int bcnn = n > x ? n : x;
        int temp = bcnn;
        while (true) {
            if (bcnn % n == 0 && bcnn % x == 0) {
                return bcnn;
            }
            bcnn += temp;
        }
    }

    public float exam64(int n, int x) {
        return (float) -x / n;
    }

    public String exam65(int n, int x, int y) {
        if (n == 0) {
            if (x == 0) return "pt vo nghiem";
            return "nghiem cua pt la " + (-y) / x;
        }
        float delta = x * x - 4 * n * y;
        float x1, x2;
        if (delta > 0) {
            x1 = (float) ((-x + Math.sqrt(delta)) / (2 * n));
            x2 = (float) ((-x - Math.sqrt(delta)) / (2 * n));
            return "Phương trình có 2 nghiệm là: " + "x1 = " + x1 + " và x2 = " + x2;
        } else if (delta == 0) {
            x1 = (-x / (2 * n));
            return "Phương trình có nghiệm kép: "
                    + "x1 = x2 = " + x1;
        } else {
            return "Phương trình vô nghiệm!";
        }
    }

    public String exam66(int n, int x, int y) {
        if (n == 0) {
            if (x == 0) return "pt vo nghiem";
            return "nghiem cua pt la " + (-y) / x;
        }
        float delta = x * x - 4 * n * y;
        float x1, x2;
        if (delta > 0) {
            x1 = (float) ((-x + Math.sqrt(delta)) / (2 * n));
            x2 = (float) ((-x - Math.sqrt(delta)) / (2 * n));
            if (x1 >= 0 && x2 < 0) {
                return "Phương trình có 2 nghiệm là: " + "x1 = " + Math.sqrt(x1) + " và x2 = " + -1 * Math.sqrt(x1);
            } else if (x1 < 0 && x2 >= 0) {
                return "Phương trình có 2 nghiệm là: " + "x1 = " + Math.sqrt(x2) + " và x2 = " + -1 * Math.sqrt(x2);
            } else if (x1 < 0 && x2 < 0) return "pt vo nghiem";
            else {
                return "phuong trinh co 4 nghiem la: x1 = " + Math.sqrt(x1) + ", x2 = " + -1 * Math.sqrt(x1) +
                        ", x3 = " + Math.sqrt(x2) + " va x4 = " + -1 * Math.sqrt(x2);
            }
        } else if (delta == 0) {
            x1 = (-x / (2 * n));
            if (x1 < 0) return "phuong trinh vo nghiem";
            return "phuong trinh co 2 nghiem la: x1 = " + Math.sqrt(x1) + " va x2 = " + -1 * Math.sqrt(x1);
        } else {
            return "Phương trình vô nghiệm!";
        }
    }

    public long exam67(int n, int x) {
        long temp = x;
        long total = 0;
        for (int i = 1; i <= n; i++) {
            temp *= -1 * x;
            total += temp;
        }
        return total;
    }

    public long exam68(int n, int x) {
        long temp = 1;
        long total = 0;
        for (int i = 1; i <= n; i++) {
            temp *= -1 * x * x;
            total += temp;
        }
        return total;
    }

    public long exam69(int n, int x) {
        long temp = x;
        long total = x;
        for (int i = 1; i <= n; i++) {
            temp *= -1 * x * x;
            total += temp;
        }
        return total;
    }

    public float exam70(int n) {
        float total = 0;
        float temp = 1;
        int temp2 = 1;
        for (int i = 2; i <= n; i++) {
            temp2 += i;
            temp = (float) 1 / temp2;
            temp *= -1;
            total += temp;
        }
        return 1 + total;
    }

    public float exam71(int n, int x) {
        float total = 0;
        float temp = 1;
        int ms = 0;
        int ts = 1;
        for (int i = 1; i <= n; i++) {
            ts *= x;
            ms += i;
            temp = (float) ts / ms;
            temp *= -1;
            total += temp;
        }
        return total;
    }
}
